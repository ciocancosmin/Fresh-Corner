<?php

namespace MongoDB\Tests\Operation;

use MongoDB\Tests\TestCase as BaseTestCase;

/**
 * Base class for Operation unit tests.
 */
abstract class TestCase extends BaseTestCase
{
}
