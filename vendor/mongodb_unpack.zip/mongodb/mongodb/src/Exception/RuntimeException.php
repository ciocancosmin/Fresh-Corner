<?php

namespace MongoDB\Exception;

class RuntimeException extends \MongoDB\Driver\Exception\RuntimeException implements Exception
{
}
