<?php

namespace MongoDB\Exception;

class UnexpectedValueException extends \MongoDB\Driver\Exception\UnexpectedValueException implements Exception
{
}
